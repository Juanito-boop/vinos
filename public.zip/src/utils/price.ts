export function formatPrice(price: number): string {
  return `$${price.toLocaleString()}`
}

export function parsePrice(price: number): number {
  return price
}

export function getCountryFlag(country: string): string {
  const flags: Record<string, string> = {
    España: "🇪🇸",
    Francia: "🇫🇷",
    Portugal: "🇵🇹",
    Italia: "🇮🇹",
    Argentina: "🇦🇷",
    Chile: "🇨🇱",
    Uruguay: "🇺🇾",
    Colombia: "🇨🇴",
    Russia: "🇷🇺",
    Mexico: "🇲🇽",
    "Estados Unidos": "🇺🇸"
  }
  return flags[country] || "🍷"
}
