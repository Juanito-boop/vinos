'use client';

import { useState } from 'react';
import { useFormStatus } from 'react-dom';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
// import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Wine } from '@/types';
import { ReactNode } from 'react';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from '../ui/select';

const TODAS_VARIEDADES = {
  "Tinto": [
    "Carmenere",
    "Pinot Noir",
    "Marsellan",
    "Blend Tinto",
    "Merlot",
    "Syrah",
    "Bonarda",
    "Malbec",
    "Cabernet Franc",
    "Tempranillo",
    "San Giovence",
    "Monte Pulciano",
    "Nero d' Avola",
    "Quintina Rosso",
  ],
  "Blanco": [],
  "Rosado": [],
  "Espumante": []
};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? 'Guardando...' : 'Guardar cambios'}
    </Button>
  );
}

function VariedadesSelector({ defaultVariedades = [] }: { defaultVariedades?: string[] }) {
  const [seleccionadas, setSeleccionadas] = useState<string[]>(defaultVariedades);

  function toggleVariedad(v: string) {
    setSeleccionadas((prev) =>
      prev.includes(v) ? prev.filter((x) => x !== v) : [...prev, v]
    );
  }

  return (
    <div className="space-y-2">
      <Label>Variedades</Label>

      <div className="flex flex-wrap gap-2 min-h-[40px] border rounded-md p-2">
        {seleccionadas.map((v) => (
          <Badge key={v} variant="secondary" className="flex items-center gap-1">
            {v}
            <button type="button" onClick={() => toggleVariedad(v)} className="ml-1 text-xs">✕</button>
          </Badge>
        ))}
      </div>

      {/* <PopoverTrigger asChild>
          <Button type="button" variant="outline" size="sm">Seleccionar variedades</Button>
        </PopoverTrigger>
        <PopoverContent className="w-60 p-2">
          <ScrollArea className="h-40">
            <div className="space-y-1">
              {TODAS_VARIEDADES.map((v) => (
                <Button
                  key={v}
                  variant={seleccionadas.includes(v) ? 'default' : 'ghost'}
                  onClick={() => toggleVariedad(v)}
                  className="w-full justify-start"
                >
                  {v}
                </Button>
              ))}
            </div>
          </ScrollArea>
        </PopoverContent> */}

      <Select onValueChange={toggleVariedad}>
        <SelectTrigger className="w-full max-w-60">
          <SelectValue placeholder="Agregar Variedades" />
        </SelectTrigger>
        <SelectContent className="max-h-56">
          {Object.entries(TODAS_VARIEDADES).map(([categoria, variedades]) => (
            <SelectGroup key={categoria}>
              <SelectLabel>{categoria}</SelectLabel>
              {variedades.map((v) => (
                <SelectItem key={v} value={v} className='[&>[data-select-item-indicator]]:hidden'>
                  {v}
                </SelectItem>
              ))}
            </SelectGroup>
          ))}
        </SelectContent>


      </Select>

      {seleccionadas.map((v, i) => (
        <input key={i} type="hidden" name="variedades" value={v} />
      ))}
    </div>
  );
}

export default function EditWineModal({
  vino,
  children,
}: {
  vino: Wine;
  children: ReactNode;
}) {
  async function handleEdit(formData: FormData) {
    const data = Object.fromEntries(formData.entries());
    console.log('Datos enviados:', data);
    await new Promise((res) => setTimeout(res, 1000));
  }

  return (
    <Dialog>
      <DialogTrigger>{children}</DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] w-[95vw] sm:w-full overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Vino</DialogTitle>
        </DialogHeader>

        <form action={handleEdit} className="space-y-4 mt-4">
          {/* Inputs principales */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Nombre</Label>
              <Input name="nombre" defaultValue={vino.nombre} required />
            </div>

            <div>
              <Label>Precio</Label>
              <Input type="number" name="precio" defaultValue={vino.precio} required />
            </div>

            <div>
              <Label>Añada</Label>
              <Input type="number" name="anada" defaultValue={vino.anada} />
            </div>

            <div>
              <Label>Alcohol (%)</Label>
              <Input type="number" name="nivel_alcohol" defaultValue={vino.nivel_alcohol} />
            </div>

            <div>
              <Label>Stock</Label>
              <Input type="number" name="stock" defaultValue={vino.stock} />
            </div>

            <div>
              <Label>Color</Label>
              {/* <Input name="color_vino" defaultValue={vino.color_vino} /> */}
              {/* <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">Open</Button>
                </DropdownMenuTrigger>
              </DropdownMenu> */}
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona el color del Vino" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Tinto">Tinto</SelectItem>
                  <SelectItem value="Blanco">Blanco</SelectItem>
                  <SelectItem value="Rosado">Rosado</SelectItem>
                  <SelectItem value="Espumante">Espumante</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>País</Label>
              <Input name="pais_importacion" defaultValue={vino.pais_importacion} />
            </div>

            <div>
              <Label>URL Imagen</Label>
              <Input name="url_imagen" defaultValue={vino.url_imagen} />
            </div>
          </div>

          <div>
            <Label>Descripción</Label>
            <Textarea name="descripcion" defaultValue={vino.descripcion} />
          </div>

          {/* Variedades */}
          <VariedadesSelector defaultVariedades={vino.variedades} />

          {/* WineDetails */}
          <div className="grid grid-cols-2 gap-4 pt-4">
            <div>
              <Label>Bodega</Label>
              <Input name="bodega" defaultValue={vino.wine_details.bodega} />
            </div>

            <div>
              <Label>Notas de cata</Label>
              <Input name="notas_cata" defaultValue={vino.wine_details.notas_cata} />
            </div>

            <div>
              <Label>Tipo de crianza</Label>
              <Input name="tipo_crianza" defaultValue={vino.wine_details.tipo_crianza} />
            </div>

            <div>
              <Label>Contenido azúcar</Label>
              <Input name="contenido_azucar" defaultValue={vino.wine_details.contenido_azucar} />
            </div>

            <div>
              <Label>Contenido carbonico</Label>
              <Input name="contenido_carbonico" defaultValue={vino.wine_details.contenido_carbonico} />
            </div>
          </div>

          {/* Submit */}
          <div className="pt-4">
            <SubmitButton />
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
