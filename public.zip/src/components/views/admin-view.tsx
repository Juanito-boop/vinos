"use client"

import { AdminPanel } from "../admin-panel"

export function AdminView() {
  return (
    <section aria-label="Panel de administración">
      <AdminPanel />
    </section>
  )
} 