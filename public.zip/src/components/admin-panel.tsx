"use client"

import WineTable from "./wine-table";
import { WineService } from "@/lib/services/wine-service";

const wines = await WineService.getAllWines()

export function AdminPanel() {
  return (
    <div className="bg-gradient-to-br from-white via-red-50 to-purple-50 rounded-lg shadow-lg border border-red-200 p-6">
      <WineTable wines={wines} className="w-full" />
    </div>
  )
}
