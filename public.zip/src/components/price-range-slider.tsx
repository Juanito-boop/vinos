"use client"

import { useState, useEffect, useRef } from "react"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { formatPrice } from "@/utils/price"

interface PriceRangeSliderProps {
  minPrice: number
  maxPrice: number
  currentMin: number
  currentMax: number
  onRangeChange: (min: number, max: number) => void
}

export function PriceRangeSlider({
  minPrice,
  maxPrice,
  currentMin,
  currentMax,
  onRangeChange,
}: PriceRangeSliderProps) {
  const [localMin, setLocalMin] = useState(currentMin)
  const [localMax, setLocalMax] = useState(currentMax)
  const [isDragging, setIsDragging] = useState<"min" | "max" | null>(null)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const sliderRef = useRef<HTMLDivElement>(null)
  const animationFrameRef = useRef<number | null>(null)

  // Actualizar valores locales cuando cambien los props
  useEffect(() => {
    setLocalMin(currentMin)
    setLocalMax(currentMax)
  }, [currentMin, currentMax])

  const handleMinInputChange = (value: string) => {
    const numValue = parseInt(value) || minPrice
    const newMin = Math.max(minPrice, Math.min(numValue, localMax))
    setLocalMin(newMin)
    onRangeChange(newMin, localMax)
  }

  const handleMaxInputChange = (value: string) => {
    const numValue = parseInt(value) || maxPrice
    const newMax = Math.min(maxPrice, Math.max(numValue, localMin))
    setLocalMax(newMax)
    onRangeChange(localMin, newMax)
  }

  const handleSliderClick = (e: React.MouseEvent) => {
    if (!sliderRef.current || isTransitioning) return

    const rect = sliderRef.current.getBoundingClientRect()
    const clickX = e.clientX - rect.left
    const percentage = Math.max(0, Math.min(1, clickX / rect.width))
    const value = Math.round(minPrice + percentage * (maxPrice - minPrice))

    // Determinar cuál slider mover basado en la distancia
    const minDistance = Math.abs(value - localMin)
    const maxDistance = Math.abs(value - localMax)

    if (minDistance < maxDistance) {
      // Mover slider mínimo
      const newMin = Math.max(minPrice, Math.min(value, localMax))
      setLocalMin(newMin)
      onRangeChange(newMin, localMax)
    } else {
      // Mover slider máximo
      const newMax = Math.min(maxPrice, Math.max(value, localMin))
      setLocalMax(newMax)
      onRangeChange(localMin, newMax)
    }
  }

  const handleSliderTouch = (e: React.TouchEvent) => {
    if (!sliderRef.current || isTransitioning) return

    const rect = sliderRef.current.getBoundingClientRect()
    const touch = e.touches[0]
    const clickX = touch.clientX - rect.left
    const percentage = Math.max(0, Math.min(1, clickX / rect.width))
    const value = Math.round(minPrice + percentage * (maxPrice - minPrice))

    // Determinar cuál slider mover basado en la distancia
    const minDistance = Math.abs(value - localMin)
    const maxDistance = Math.abs(value - localMax)

    if (minDistance < maxDistance) {
      // Mover slider mínimo
      const newMin = Math.max(minPrice, Math.min(value, localMax))
      setLocalMin(newMin)
      onRangeChange(newMin, localMax)
    } else {
      // Mover slider máximo
      const newMax = Math.min(maxPrice, Math.max(value, localMin))
      setLocalMax(newMax)
      onRangeChange(localMin, newMax)
    }
  }

  const handleMinSliderMouseDown = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging("min")
    setIsTransitioning(true)
    
    const handleMouseMove = (e: MouseEvent) => {
      if (!sliderRef.current) return
      
      // Usar requestAnimationFrame para movimiento más suave
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      
      animationFrameRef.current = requestAnimationFrame(() => {
        const rect = sliderRef.current!.getBoundingClientRect()
        const percentage = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width))
        const value = Math.round(minPrice + percentage * (maxPrice - minPrice))
        const newMin = Math.max(minPrice, Math.min(value, localMax))
        
        setLocalMin(newMin)
        // No llamar onRangeChange durante el arrastre para evitar actualizaciones constantes de URL
      })
    }

    const handleMouseUp = () => {
      setIsDragging(null)
      setIsTransitioning(false)
      // Llamar onRangeChange solo cuando se complete el arrastre
      onRangeChange(localMin, localMax)
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }

    document.addEventListener("mousemove", handleMouseMove)
    document.addEventListener("mouseup", handleMouseUp)
  }

  const handleMaxSliderMouseDown = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging("max")
    setIsTransitioning(true)
    
    const handleMouseMove = (e: MouseEvent) => {
      if (!sliderRef.current) return
      
      // Usar requestAnimationFrame para movimiento más suave
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      
      animationFrameRef.current = requestAnimationFrame(() => {
        const rect = sliderRef.current!.getBoundingClientRect()
        const percentage = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width))
        const value = Math.round(minPrice + percentage * (maxPrice - minPrice))
        const newMax = Math.min(maxPrice, Math.max(value, localMin))
        
        setLocalMax(newMax)
        onRangeChange(localMin, newMax)
      })
    }

    const handleMouseUp = () => {
      setIsDragging(null)
      setIsTransitioning(false)
      // Llamar onRangeChange solo cuando se complete el arrastre
      onRangeChange(localMin, localMax)
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }

    document.addEventListener("mousemove", handleMouseMove)
    document.addEventListener("mouseup", handleMouseUp)
  }

  const handleMinSliderTouchStart = (e: React.TouchEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging("min")
    setIsTransitioning(true)
    
    const handleTouchMove = (e: TouchEvent) => {
      if (!sliderRef.current) return
      
      // Usar requestAnimationFrame para movimiento más suave
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      
      animationFrameRef.current = requestAnimationFrame(() => {
        const rect = sliderRef.current!.getBoundingClientRect()
        const touch = e.touches[0]
        const percentage = Math.max(0, Math.min(1, (touch.clientX - rect.left) / rect.width))
        const value = Math.round(minPrice + percentage * (maxPrice - minPrice))
        const newMin = Math.max(minPrice, Math.min(value, localMax))
        
        setLocalMin(newMin)
        onRangeChange(newMin, localMax)
      })
    }

    const handleTouchEnd = () => {
      setIsDragging(null)
      setIsTransitioning(false)
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      document.removeEventListener("touchmove", handleTouchMove)
      document.removeEventListener("touchend", handleTouchEnd)
    }

    document.addEventListener("touchmove", handleTouchMove)
    document.addEventListener("touchend", handleTouchEnd)
  }

  const handleMaxSliderTouchStart = (e: React.TouchEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging("max")
    setIsTransitioning(true)
    
    const handleTouchMove = (e: TouchEvent) => {
      if (!sliderRef.current) return
      
      // Usar requestAnimationFrame para movimiento más suave
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      
      animationFrameRef.current = requestAnimationFrame(() => {
        const rect = sliderRef.current!.getBoundingClientRect()
        const touch = e.touches[0]
        const percentage = Math.max(0, Math.min(1, (touch.clientX - rect.left) / rect.width))
        const value = Math.round(minPrice + percentage * (maxPrice - minPrice))
        const newMax = Math.min(maxPrice, Math.max(value, localMin))
        
        setLocalMax(newMax)
        onRangeChange(localMin, newMax)
      })
    }

    const handleTouchEnd = () => {
      setIsDragging(null)
      setIsTransitioning(false)
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      document.removeEventListener("touchmove", handleTouchMove)
      document.removeEventListener("touchend", handleTouchEnd)
    }

    document.addEventListener("touchmove", handleTouchMove)
    document.addEventListener("touchend", handleTouchEnd)
  }

  const minPercentage = ((localMin - minPrice) / (maxPrice - minPrice)) * 100
  const maxPercentage = ((localMax - minPrice) / (maxPrice - minPrice)) * 100

  return (
    <Card className="border-0">
      <CardHeader className="p-0 pb-3">
        <CardTitle className="text-sm font-medium">Rango de Precio</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 p-0">
        {/* Inputs de precio */}
        <div className="flex gap-2">
          <div className="flex-1">
            <Label htmlFor="min-price" className="text-xs text-muted-foreground">
              Mínimo
            </Label>
            <Input
              id="min-price"
              type="number"
              value={localMin}
              onChange={(e) => handleMinInputChange(e.target.value)}
              min={minPrice}
              max={localMax}
              step={10000}
              className="text-sm"
              placeholder="Precio mínimo"
            />
          </div>
          <div className="flex-1">
            <Label htmlFor="max-price" className="text-xs text-muted-foreground">
              Máximo
            </Label>
            <Input
              id="max-price"
              type="number"
              value={localMax}
              onChange={(e) => handleMaxInputChange(e.target.value)}
              min={localMin}
              max={maxPrice}
              step={10000}
              className="text-sm"
              placeholder="Precio máximo"
            />
          </div>
        </div>

        {/* Slider de rango */}
        <div className="relative pt-6 px-4 mx-auto">
          <div
            ref={sliderRef}
            className="relative h-2 bg-gray-200 rounded-full cursor-pointer"
            onClick={handleSliderClick}
            onTouchStart={handleSliderTouch}
          >
            {/* Track de rango seleccionado */}
            <div
              className="absolute h-2 bg-red-500 rounded-full transition-all duration-150 ease-out"
              style={{
                left: `${minPercentage}%`,
                width: `${maxPercentage - minPercentage}%`,
              }}
            />
            
            {/* Slider mínimo */}
            <div
              className={`absolute w-4 h-4 bg-red-600 rounded-full border-2 border-white shadow-md cursor-pointer transform -translate-y-1 hover:scale-110 z-10 touch-none transition-all duration-150 ease-out ${
                isDragging === "min" ? "scale-110 shadow-lg" : ""
              }`}
              style={{ 
                left: `${minPercentage}%`,
                transition: isDragging ? "none" : "all 150ms ease-out"
              }}
              onMouseDown={handleMinSliderMouseDown}
              onTouchStart={handleMinSliderTouchStart}
            />
            
            {/* Slider máximo */}
            <div
              className={`absolute w-4 h-4 bg-red-600 rounded-full border-2 border-white shadow-md cursor-pointer transform -translate-y-1 hover:scale-110 z-10 touch-none transition-all duration-150 ease-out ${
                isDragging === "max" ? "scale-110 shadow-lg" : ""
              }`}
              style={{ 
                left: `${maxPercentage}%`,
                transition: isDragging ? "none" : "all 150ms ease-out"
              }}
              onMouseDown={handleMaxSliderMouseDown}
              onTouchStart={handleMaxSliderTouchStart}
            />
          </div>
          
          {/* Etiquetas de precio */}
          <div className="flex justify-between mt-2 text-xs text-muted-foreground">
            <span>{formatPrice(minPrice)}</span>
            <span>{formatPrice(maxPrice)}</span>
          </div>
        </div>

        {/* Valores actuales */}
        <div className="text-center text-sm text-muted-foreground bg-gray-50 py-2 rounded transition-all duration-150 ease-out">
          {formatPrice(localMin)} - {formatPrice(localMax)}
        </div>
      </CardContent>
    </Card>
  )
} 