import type { Wine } from "@/types"

export const wines: Wine[] = []